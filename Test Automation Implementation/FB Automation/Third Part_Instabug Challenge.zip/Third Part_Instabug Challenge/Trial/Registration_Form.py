from selenium import webdriver
import os
import unittest
from Read_Test_Data import getCSVData
from ddt import ddt, data, unpack
from selenium.webdriver.support.select import Select
import time

@ddt
class Registration(unittest.TestCase):

    def setUp(self):

        # Locating Chrome Webdriver
        driverLocation = "chromedriver.exe"
        os.environ["webdriver.chrome.driver"] = driverLocation
        self.driver = webdriver.Chrome(driverLocation)

        # Maximizing Chrome Window
        self.driver.maximize_window()
        self.driver.implicitly_wait(15)

        # Navigating to FB URL
        self.driver.get("https://www.facebook.com/")


    @data(*getCSVData('Input_Data.csv'))
    @unpack
    def test_FormFilling(self, FirstName, LastName, email, PW, BD_Day, BD_M, BD_Y, F_M_C):

        #Old VS New Design
        Old_Design = self.driver.find_elements_by_xpath("//a[@title='Go to Facebook home']")
        old_design_length = Old_Design.__len__()
        if old_design_length > 0:
            #Locating FirstName Element
            FirsNameElement = self.driver.find_element_by_xpath(".//input[@name='firstname']")
            FirsNameElement.click()
            FirsNameElement.clear()
            FirsNameElement.send_keys(FirstName)

            #Locating LastName Element
            LastNameElement = self.driver.find_element_by_xpath(".//input[@name='lastname']")
            LastNameElement.click()
            LastNameElement.clear()
            LastNameElement.send_keys(LastName)

            #Locating Email
            EmailElement = self.driver.find_element_by_xpath(".//input[@name='reg_email__']")
            EmailElement.click()
            EmailElement.clear()
            EmailElement.send_keys(email)

            #Locating Email confirmation
            Conf_EmailElement = self.driver.find_element_by_xpath(".//input[@name='reg_email_confirmation__']")
            Conf_EmailElement.click()
            Conf_EmailElement.clear()
            Conf_EmailElement.send_keys(email)

            #Locating PW
            PassWElement = self.driver.find_element_by_xpath(".//input[@name='reg_passwd__']")
            PassWElement.click()
            PassWElement.clear()
            PassWElement.send_keys(PW)

            #Locating BD-Day
            BDay = self.driver.find_element_by_id("day")
            sel = Select(BDay)
            sel.select_by_value(BD_Day)


            #Locating BD-Month
            BD_Month = self.driver.find_element_by_id("month")
            sel = Select(BD_Month)
            sel.select_by_value(BD_M)


            #Locating BD-Year
            BD_Year = self.driver.find_element_by_id("year")
            sel = Select(BD_Year)
            sel.select_by_value(BD_Y)


            Sex = F_M_C
            if Sex == "Female":
                Female = self.driver.find_element_by_id("u_0_6")
                Female.click()
            elif Sex == "Male":
                Male = self.driver.find_element_by_id("u_0_7")
                Male.click()
            else:
                Custom = self.driver.find_element_by_id("u_0_8")
                Custom.click()


        else:
            Create_New_Account = self.driver.find_element_by_id("u_0_2")
            Create_New_Account.click()

            # Locating FirstName Element
            FirsNameElement = self.driver.find_element_by_xpath(".//input[@name='firstname']")
            FirsNameElement.click()
            FirsNameElement.clear()
            FirsNameElement.send_keys(FirstName)

            # Locating LastName Element
            LastNameElement = self.driver.find_element_by_xpath(".//input[@name='lastname']")
            LastNameElement.click()
            LastNameElement.clear()
            LastNameElement.send_keys(LastName)

            # Locating Email
            EmailElement = self.driver.find_element_by_xpath(".//input[@name='reg_email__']")
            EmailElement.click()
            EmailElement.clear()
            EmailElement.send_keys(email)

            # Locating Email confirmation
            Conf_EmailElement = self.driver.find_element_by_xpath(".//input[@name='reg_email_confirmation__']")
            Conf_EmailElement.click()
            Conf_EmailElement.clear()
            Conf_EmailElement.send_keys(email)

            # Locating PW
            PassWElement = self.driver.find_element_by_xpath(".//input[@name='reg_passwd__']")
            PassWElement.click()
            PassWElement.clear()
            PassWElement.send_keys(PW)

            # Locating BD-Day
            BDay = self.driver.find_element_by_id("day")
            sel = Select(BDay)
            sel.select_by_value(BD_Day)


            # Locating BD-Month
            BD_Month = self.driver.find_element_by_id("month")
            sel = Select(BD_Month)
            sel.select_by_value(BD_M)


            # Locating BD-Year
            BD_Year = self.driver.find_element_by_id("year")
            sel = Select(BD_Year)
            sel.select_by_value(BD_Y)


            Sex = F_M_C
            if Sex == "Female":
                Female = self.driver.find_element_by_id("u_1g_4")
                Female.click()
            elif Sex == "Male":
                Male = self.driver.find_element_by_id("u_1g_5")
                Male.click()
            else:
                Custom = self.driver.find_element_by_id("u_1g_6")
                Custom.click()



if __name__ == '__main__':
    unittest.main()
