from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import os
import unittest
from Read_Test_Data import getCSVData
from ddt import ddt, data, unpack
from selenium.webdriver.support.select import Select

@ddt
class FirstTrial(unittest.TestCase):

    def setUp(self):

        # Locating Chrome Webdriver
        driverLocation = "chromedriver.exe"
        os.environ["webdriver.chrome.driver"] = driverLocation
        self.driver = webdriver.Chrome(driverLocation)

        # Maximizing Chrome Window
        self.driver.maximize_window()

        # Navigating to FB URL
        self.driver.get("https://www.facebook.com/")

    @data(*getCSVData('Input_Data.csv'))
    @unpack
    def Form_Filling(self, FirstName, LastName, email, PW, BD_Day, BD_M, BD_Y, F_M_C):

        # Locating FirstName Element
        FirsNameElement = self.driver.find_element_by_xpath(".//input[@name='firstname']")
        FirsNameElement.click()
        FirsNameElement.clear()
        FirsNameElement.send_keys(FirstName)

        # Locating LastName Element
        LastNameElement = self.driver.find_element_by_xpath(".//input[@name='lastname']")
        LastNameElement.click()
        LastNameElement.clear()
        LastNameElement.send_keys(LastName)

        # Locating Email
        EmailElement = self.driver.find_element_by_xpath(".//input[@name='reg_email__']")
        EmailElement.click()
        EmailElement.clear()
        EmailElement.send_keys(email)

        # Locating PW
        PassWElement = self.driver.find_element_by_xpath(".//input[@name='reg_passwd__']")
        PassWElement.click()
        PassWElement.clear()
        PassWElement.send_keys(PW)

        # Locating BD-Day
        BDay = self.driver.find_element_by_id("day")
        sel = Select(BDay)
        sel.select_by_value(BD_Day)

        # Locating BD-Month
        BD_Month = self.driver.find_element_by_id("month")
        sel = Select(BD_Month)
        sel.select_by_value(BD_M)

        # Locating BD-Year
        BD_Y = self.driver.find_element_by_id("year")
        sel = Select(BD_Y)
        sel.select_by_value(BD_Y)

        Sex = F_M_C
        if Sex == "Female":
            Female = self.driver.find_element_by_id("u_3_4")
            Female.click()
        elif Sex == "Male":
            Male = self.driver.find_element_by_id("u_3_5")
            Male.click()
        else:
            Custom = self.driver.find_element_by_id("u_3_6")
            Custom.click()


    @data(*getCSVData('Test_Data_ValidLogin.csv'))
    @unpack
    def test_ValidLogin(self, email, password):

        #Locating Email Filed, Clicking on it, Clearing it and entering email value
        EmailElement = self.driver.find_element_by_xpath(".//input[@name='email']")
        EmailElement.click()
        EmailElement.clear()
        EmailElement.send_keys(email)

        # Locating Password Filed, Clicking on it, Clearing it and entering password value
        PasswordElement = self.driver.find_element_by_xpath(".//input[@name='pass']")
        PasswordElement.click()
        PasswordElement.clear()
        PasswordElement.send_keys(password)

        # Locating Login Button, Clicking on it to perform login action
        LoginButton = self.driver.find_element_by_xpath(".//*[@type='submit']")
        LoginButton.click()

        option = Options()

        option.add_experimental_option("prefs", {
            "profile.default_content_setting_values.notifications": 1
        })

        driver = webdriver.Chrome(options=option, executable_path="chromedriver.exe")

        #Successful Login Validation
        Home = self.driver.find_element_by_xpath(".//*[@data-click='home_icon']")
        if Home is not None:
            print("Login Successful")


    @data(*getCSVData('Test_Data_InValidPW.csv'))
    @unpack
    def test_InValidPW(self, email, password):

            # Locating Email Filed, Clicking on it, Clearing it and entering email value
            EmailElement = self.driver.find_element_by_xpath(".//input[@name='email']")
            EmailElement.click()
            EmailElement.clear()
            EmailElement.send_keys(email)

            # Locating Password Filed, Clicking on it, Clearing it and entering password value
            PasswordElement = self.driver.find_element_by_xpath(".//input[@name='pass']")
            PasswordElement.click()
            PasswordElement.clear()
            PasswordElement.send_keys(password)

            # Locating Login Button, Clicking on it to perform login action
            LoginButton = self.driver.find_element_by_xpath(".//*[@type='submit']")
            LoginButton.click()

            # Failed Login Validation
            Not_Me = self.driver.find_element_by_xpath(".//*[@id='not_me_link']")
            if Not_Me is not None:
                print("Wrong PW Validation Succeeded")

    @data(*getCSVData('Test_Data_InValid_Email.csv'))
    @unpack
    def test_InValid_Email(self, email, password):

        # Locating Email Filed, Clicking on it, Clearing it and entering email value
        EmailElement = self.driver.find_element_by_xpath(".//input[@name='email']")
        EmailElement.click()
        EmailElement.clear()
        EmailElement.send_keys(email)

        # Locating Password Filed, Clicking on it, Clearing it and entering password value
        PasswordElement = self.driver.find_element_by_xpath(".//input[@name='pass']")
        PasswordElement.click()
        PasswordElement.clear()
        PasswordElement.send_keys(password)

        # Locating Login Button, Clicking on it to perform login action
        LoginButton = self.driver.find_element_by_xpath(".//*[@type='submit']")
        LoginButton.click()

        # Failed Login Validation
        Recover_Account = self.driver.find_element_by_link_text("Recover Your Account")
        if Recover_Account is not None:
            print("Wrong Email Validation Succeeded")


if __name__ == '__main__':
    unittest.main()







